import json
import boto3
import os
import pandas as pd

s3_client = boto3.client("s3")
# Hardcoded S3 variables 
# bucket = "snowboard-finder"
key = "all_boards_20201220.csv"
tmp_csv_file = '/tmp/{}'.format(key)
bucket = os.environ['BUCKET_NAME']


# create a DynamoDB object using the AWS SDK
dynamodb = boto3.resource('dynamodb')
# use the DynamoDB object to select our table
table = dynamodb.Table('SnowboardDatabase')

def save_to_dynamodb(row, db_table=table):

   
    return db_table.put_item(
        Item={
            'gender': row['gender'], 
            'id': row['id'],
            'board_name': row['board_name'],
            'url': row['url'],
            'Overall Rating': row['Overall Rating'],
            'Riding Style': row['Riding Style'],
            'Riding Level': row['Riding Level'],
            'Fits Boot size (US)': str(row['Fits Boot size (US)']),
            'Manufactured in': row['Manufactured in'], 
            'Shape': row['Shape'], 
            'Camber Profile': row['Camber Profile'],
            'Stance': row['Stance'],
            'Speed': str(row['Speed']),
            'Approx. Weight': str(row['Approx. Weight']),
            'Powder': row['Powder'], 
            # 'Turning Experience': row['Turning Experience'],
            # 'Carving': row['Carving'],
            # 'Uneven Terrain': row['Uneven Terrain'],
            # 'Switch': row['Switch'], 
            # 'Jumps': row['Jumps'],
            # 'Jibbing': row['Jibbing'],
            # 'Pipe': row['Pipe'],
            'year': str(row['year'])
        }
        )



def lambda_handler(event, context):
    
    s3_client.download_file(bucket, key, tmp_csv_file)
    df = pd.read_csv(tmp_csv_file)
    
    for idx, row in df.iterrows():
        save_to_dynamodb(row)   
                  
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('All data saved to Dynamo DB: {}'.format(table))
    }
